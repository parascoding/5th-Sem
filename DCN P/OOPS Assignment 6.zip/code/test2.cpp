#include <bits/stdc++.h>
using namespace std;
fstream file;
class Person
{
    string name;
    string contactNo;
    string city;
    int age;

public:
    Person(){
        name = "ABCD";
        contactNo = "0000";
        city = "New Delhi";
        age = 0;
    }

    string getName();
    void setName(string);
    string getContactNo();
    void setContactNo(string);
    string getCity();
    void setCity(string);
    int getAge();
    void setAge(int);

    ~Person(){}
};

string Person ::getName(){
    return this->name;
}

void Person ::setName(string name){
    this->name = name;
}

string Person ::getContactNo(){
    return this->contactNo;
}

void Person ::setContactNo(string contactNo){
    this->contactNo = contactNo;
}

string Person ::getCity(){
    return this->city;
}

void Person ::setCity(string city){
    this->city = city;
}

int Person ::getAge(){
    return this->age;
}

void Person ::setAge(int age){
    this->age = age;
}

class Student : public Person
{
    string roll_no;
    float cpi;
    string degree;
    string institute;
    static int count;
public:
    Student(){
        file<<"Student "<<count++<<" is created\n";
    }

    string getRoll_no();
    void setRoll_no(string);
    float getCpi();
    void setCpi(float);
    string getDegree();
    void setDegree(string);
    string getInstitute();
    void setInstitute(string);

    ~Student(){
        file<<"Student "<<count--<<" is destroyed\n";
    }
};
int Student::count=0;
string Student ::getRoll_no(){
    return this->roll_no;
}

void Student ::setRoll_no(string roll_no){
    this->roll_no = roll_no;
}

float Student ::getCpi(){
    return this->cpi;
}

void Student ::setCpi(float cpi){
    this->cpi = cpi;
}

string Student ::getDegree(){
    return this->degree;
}

void Student ::setDegree(string degree){
    this->degree = degree;
}

string Student ::getInstitute(){
    return this->institute;
}

void Student ::setInstitute(string institute){
    this->institute = institute;
}

class Employee : public Student // 
{
    string emp_id;
    int salary;
    string designation;
    string DOJ;
    static int count;

public:
    Employee(){
        file<<"Employee "<<count++<<" is created\n";
    }

    string getEmp_id();
    void setEmp_id(string);
    int getSalary();
    void setSalary(int);
    string getDesignation();
    void setDesignation(string);
    string getDOJ();
    void setDOJ(string);

    ~Employee(){
        file<<"Employee "<<count--<<" is destroyed\n";
    }
};
int Employee::count=0;
string Employee ::getEmp_id(){
    return this->emp_id;
}

void Employee ::setEmp_id(string emp_id){
    this->emp_id = emp_id;
}

int Employee ::getSalary(){
    return this->salary;
}

void Employee ::setSalary(int salary){
    this->salary = salary;
}

string Employee ::getDesignation(){
    return this->designation;
}

void Employee ::setDesignation(string designation){
    this->designation = designation;
}

string Employee ::getDOJ(){
    return this->DOJ;
}

void Employee ::setDOJ(string DOJ){
    this->DOJ = DOJ;
}

int main(){
    file.open("output2.txt",ios::trunc | ios::out | ios::in);
    Employee *employee=new Employee[5];
    Student *student=new Student[3];

    student[0].setName("Paras Yadav");
    student[0].setRoll_no("120CS0005");
    student[0].setCpi(8.78);
    student[0].setAge(17);
    student[0].setDegree("B.Tech. CSE");
    student[0].setInstitute("IIITDM Kurnool");

    file<<"Details of Student are - \n";
    file<<"Name - "<<student[0].getName()<<endl;
    file<<"Roll No - "<<student[0].getRoll_no()<<endl;
    file<<"CPI - "<<student[0].getCpi()<<endl;
    file<<"Age - "<<student[0].getAge()<<endl;
    file<<"Institute - "<<student[0].getInstitute()<<endl;
    file<<"Degree Pursuing - "<<student[0].getDegree()<<endl;


    employee[0].setName("Aman Prakash");
    employee[0].setContactNo("9140052985");
    employee[0].setCity("Kanpur");
    employee[0].setEmp_id("123");
    employee[0].setDegree("PhD");
    employee[0].setSalary(10000);
    employee[0].setDOJ("31/12/1999");
    employee[0].setAge(36);
    // Considering the case where employee was
    // the student in same firm/Institute. 
    employee[0].setRoll_no("1995CS0005");

    file<<"Details of Employee are - \n";
    file<<"Name - "<<employee[0].getName()<<endl;
    file<<"Employee id - "<<employee[0].getEmp_id()<<endl;
    file<<"Contact No. - "<<employee[0].getContactNo()<<endl;
    file<<"Salary - "<<employee[0].getSalary()<<endl;
    file<<"City - "<<employee[0].getCity()<<endl;
    file<<"Age - "<<employee[0].getAge()<<endl;
    file<<"Date of Joining - "<<employee[0].getDOJ()<<endl;


    delete[] employee;
    delete[] student;
    return 0;
}