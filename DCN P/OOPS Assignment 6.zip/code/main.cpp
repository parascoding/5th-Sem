#include<bits/stdc++.h>
using namespace std;
fstream file;
class Player{
    string name;
    string debutDate;
    int jerseyNo;
    int noOfMathesPlayed;

public:
    string getName();
    int getNoOfMathesPlayed();
    void setNoOfMathesPlayed(int noOfMathesPlayed);
    void setName(string name);
    string getDebutDate();
    void setDebutDate(string debutDate);
    int getJerseyNo();
    void setJerseyNo(int jerseyNo);

    // Giving friend acess to Batsman, Bowler
    // and all rounder. 
    friend class Batsman;
    friend class Bowler;
    friend class AllRounder;
};
// --------------------------------------------
int Player::getNoOfMathesPlayed() {
		return this->noOfMathesPlayed;
}

void Player::setNoOfMathesPlayed(int noOfMathesPlayed) {
    this->noOfMathesPlayed = noOfMathesPlayed;
}
string Player::getName() {
    return this->name;
}

void Player::setName(string name) {
    this->name = name;
}

string Player::getDebutDate() {
    return this->debutDate;
}

void Player::setDebutDate(string debutDate) {
    this->debutDate = debutDate;
}

int Player::getJerseyNo() {
    return this->jerseyNo;
}

void Player::setJerseyNo(int jerseyNo) {
    this->jerseyNo = jerseyNo;
}
// --------------------------------------------
class Batsman:virtual public Player{
    double strikeRate;
    double average;
    // Left Handed or Right handed. 
    string battingStyle;
    int halfCenturies;
    int Centuries;
    static int count;
public:
    Batsman(){
        file<<"Batsman "<<count++<<" is created\n";
    }
    double getStrikeRate();
    void setStrikeRate(double strikeRate);
    double getAverage();
    void setAverage(double average);
    string getBattingStyle();
    void setBattingStyle(string battingStyle);
    void setHalfCenturies(int halfCenturies);
    int getCenturies();
    void setCenturies(int Centuries);
    int getHalfCenturies();
    ~Batsman(){
        file<<"Batsman "<<count--<<" is destroyed\n";
    }
};
// --------------------------------------------
double Batsman::getStrikeRate() {
    return this->strikeRate;
}

void Batsman::setStrikeRate(double strikeRate) {
    this->strikeRate = strikeRate;
}

double Batsman::getAverage() {
    return this->average;
}

void Batsman::setAverage(double average) {
    this->average = average;
}

string Batsman::getBattingStyle() {
    return this->battingStyle;
}

void Batsman::setBattingStyle(string battingStyle) {
    this->battingStyle = battingStyle;
}

int Batsman::getHalfCenturies() {
    return this->halfCenturies;
}

void Batsman::setHalfCenturies(int halfCenturies) {
    this->halfCenturies = halfCenturies;
}

int Batsman::getCenturies() {
    return this->Centuries;
}

void Batsman::setCenturies(int Centuries) {
    this->Centuries = Centuries;
}
int Batsman::count=1;
// --------------------------------------------
class Bowler: virtual public Player{
    int wickets;
    int economy;
    int bowlingAverage;
    // Spinner, Fast, Medium
    string bowlingStyle;
    // Left or Right
    string bowlingHand;
    static int count;
public:
    Bowler(){
        file<<"Bowler "<<count++<<" is created\n";
    }
    int getWickets();
    void setWickets(int wickets);
    int getEconomy();
    void setEconomy(int economy);
    int getBowlingAverage();
    void setBowlingAverage(int bowlingAverage);
    string getBowlingStyle();
    void setBowlingStyle(string bowlingStyle);
    string getBowlingHand();
    void setBowlingHand(string bowlingHand);
    ~Bowler(){
        file<<"Bowler "<<count--<<" is destroyed\n";
    }

};
// --------------------------------------------
int Bowler::getWickets() {
    return this->wickets;
}

void Bowler::setWickets(int wickets) {
    this->wickets = wickets;
}

int Bowler::getEconomy() {
    return this->economy;
}

void Bowler::setEconomy(int economy) {
    this->economy = economy;
}

int Bowler::getBowlingAverage() {
    return this->bowlingAverage;
}

void Bowler::setBowlingAverage(int bowlingAverage) {
    this->bowlingAverage = bowlingAverage;
}

string Bowler::getBowlingStyle() {
    return this->bowlingStyle;
}

void Bowler::setBowlingStyle(string bowlingStyle) {
    this->bowlingStyle = bowlingStyle;
}

string Bowler::getBowlingHand() {
    return this->bowlingHand;
}

void Bowler::setBowlingHand(string bowlingHand) {
    this->bowlingHand = bowlingHand;
}
int Bowler::count=0;
// --------------------------------------------

class AllRounder:public Batsman, public Bowler{
    string favouriteFieldingPosition;
    int noOfCatches;
    static int count;
public:
    AllRounder(){
        file<<"Allrounder "<<count++<<" is created\n";
    }
    ~AllRounder(){
        file<<"Allrounder "<<count--<<" is destroyed\n";
    }
    int getNoOfCatches();
    void setNoOfCatches(int noOfCatches);
    string getFavouriteFieldingPosition();
    void setFavouriteFieldingPosition(string favouriteFieldingPosition);
};
// ---------------------------------------------------------
int AllRounder::getNoOfCatches() {
    return this->noOfCatches;
}

void AllRounder::setNoOfCatches(int noOfCatches) {
    this->noOfCatches = noOfCatches;
}
string AllRounder::getFavouriteFieldingPosition() {
    return this->favouriteFieldingPosition;
}

void AllRounder::setFavouriteFieldingPosition(string favouriteFieldingPosition) {
    this->favouriteFieldingPosition = favouriteFieldingPosition;
}
int AllRounder::count=1;
// ---------------------------------------------------------
int main(){
    file.open("output.txt",ios::trunc | ios::out | ios::in);
    Batsman *batsman=new Batsman[6];
    Bowler *bowler=new Bowler[3];
    AllRounder *allRounder=new AllRounder[2];

    batsman[0].setName("Rohit Sharma");
    batsman[0].setAverage(35.88);
    batsman[0].setBattingStyle("Right Handed");
    batsman[0].setCenturies(25);
    
    file<<"Batsman 1 details -\n";
    file<<"Name - "<<batsman[0].getName()<<endl;
    file<<"Average - "<<batsman[0].getAverage()<<endl;
    file<<"Batting Style - "<<batsman[0].getBattingStyle()<<endl;
    file<<"Centuries - "<<batsman[0].getCenturies()<<endl;

    bowler[0].setName("Jasprit Bumrah");
    bowler[0].setWickets(213);
    bowler[0].setBowlingStyle("Fast");
    bowler[0].setBowlingAverage(15.6);

    file<<"Bowler 1 details -\n";
    file<<"Name - "<<bowler[0].getName()<<endl;
    file<<"Average - "<<bowler[0].getBowlingAverage()<<endl;
    file<<"Bowling Style - "<<bowler[0].getBowlingStyle()<<endl;
    file<<"Wickets - "<<bowler[0].getWickets()<<endl;

    
    allRounder[0].setName("Hardik Pandya");
    allRounder[0].setWickets(32);
    allRounder[0].setAverage(25);
    allRounder[0].setBowlingAverage(15.6);


    file<<"All rounder 1 details -\n";
    file<<"Name - "<<allRounder[0].getName()<<endl;
    file<<"Average - "<<allRounder[0].getBowlingAverage()<<endl;
    file<<"Bowling Style - "<<allRounder[0].getBowlingStyle()<<endl;
    file<<"Wickets - "<<allRounder[0].getWickets()<<endl;


    delete[] batsman;
    delete[] bowler;
    delete[] allRounder;
    return 0;
}